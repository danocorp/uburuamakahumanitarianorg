<!--====== FOOTER PART START ======-->

<footer class="footer_area">
      <div class="footer_widget pt-80 pb-130">
        <div class="container">
          <div class="row">
            <div class="col-lg-4 col-md-6 order-md-1 order-lg-1">
              <div class="footer_about mt-50">
                <!--<a href="#">
                  <img src="<?php if(isset($page) && $page != 1){ echo '../';} ?>assets/images/logo-2.png" alt="Logo" />
                </a>-->

                <p>
                  Uburu Amaka Humanitarian Organization.
                </p>

                <div class="footer_contact mt-20">
                  <h5 class="footer_title">Contact us</h5>
                  <p>
                    Uburu Community Civic Centre, Eke-ajah, <br />
                    Uburu, Ohaozara L.G.A, Ebonyi State.<br>
                    <b>Tel:</b> +2348032545494 <br>
                    <b>Email: </b> uburuamakanews@gmail.com
                  </p>
                </div>
                <!-- footer contact -->
              </div>
              <!-- footer about -->
            </div>
            <div class="col-lg-5 col-md-12 order-md-3 order-lg-2">
              <div class="footer_link_wrapper d-flex flex-wrap">
                <div class="footer_link mt-50">
                  <h5 class="footer_title">Useful links</h5>
                  <ul class="link">
                    <li><a href="#">Home</a></li>
                    <li><a href="#">About us</a></li>
                    <li><a href="#">Our Causes</a></li>
                    <li><a href="#">Our Events</a></li>
                    <li><a href="#">Contact</a></li>
                  </ul>
                </div>
                <!-- footer link -->

                <div class="footer_link mt-50">
                  <h5 class="footer_title">Our Causes</h5>
                  <ul class="link">
                    <li><a href="#">Water Purify</a></li>
                    <li><a href="#">Food Collect</a></li>
                    <li><a href="#">Health Fund</a></li>
                    <li><a href="#">Free Education</a></li>
                    <li><a href="#">Poor Health</a></li>
                  </ul>
                </div>
                <!-- footer link -->
              </div>
              <!-- footer link wrapper -->
            </div>
            <div class="col-lg-3 col-md-6 order-md-2 order-lg-3">
              <div class="footer_subscribe mt-50">
                <h5 class="footer_title">Subscribe</h5>
                <p>
                  Get Uburu Amaka email alerts and keep in touch with our
                  hangouts.
                </p>
                <div class="subscribe_form">
                  <form action="#">
                    <input type="text" placeholder="Email" />
                    <button><i class="fa fa-paper-plane"></i></button>
                  </form>
                </div>
              </div>
              <!-- footer link  -->
            </div>
          </div>
          <!-- row -->
        </div>
        <!-- container -->
      </div>
      <!-- footer widget -->
      <div class="footer_copyright text-center">
        <div class="container">
          <div class="copyright">
            <p>
              Copyright &copy;
              <?php 
                date_default_timezone_set('Africa/Lagos');
                echo date('Y');
               ?>. All Rights Reserved Uburu Amaka Humanitarian Organization.
            </p>
          </div>
          <!-- copyright -->
        </div>
        <!-- container -->
      </div>
      <!-- footer copyright -->
    </footer>

    <!--====== FOOTER PART ENDS ======-->
