    <!--====== HEADER PART START ======-->

    <header class="header_area">
      <div class="header_top">
        <div class="container">
          <div class="header_top_wrapper d-md-flex justify-content-between">
            <div class="header_social text-center">
              <ul>
                <li>
                  <a href="#"><i class="fa fa-facebook-square"></i></a>
                </li>
                <li>
                  <a href="#"><i class="fa fa-twitter-square"></i></a>
                </li>
                <li>
                  <a href="#"><i class="fa fa-linkedin-square"></i></a>
                </li>
                <li>
                  <a href="#"><i class="fa fa-instagram"></i></a>
                </li>
                <li>
                  <a href="#"><i class="fa fa-pinterest-square"></i></a>
                </li>
              </ul>
            </div>
            <!-- header social -->

            <div class="header_info d-none d-md-block">
              <ul>
                <li>
                  <img src="<?php if(isset($page) && $page != 1){ echo '../';} ?>assets/images/call.png" alt="" /><a href="#"
                    >91 458 654 528</a
                  >
                </li>
                <li>
                  <img src="<?php if(isset($page) && $page != 1){ echo '../';} ?>assets/images/mail.png" alt="" /><a href="#"
                    >info@example.com</a
                  >
                </li>
                <li>
                  <img src="<?php if(isset($page) && $page != 1){ echo '../';} ?>assets/images/heand.png" alt="" /><a href="#"
                    >Become a Volunteer</a
                  >
                </li>
              </ul>
            </div>
            <!-- header info -->
          </div>
          <!-- header top wrapper -->
        </div>
        <!-- container -->
      </div>
      <!-- header top -->

      <div class="header_navbar">
        <div class="container">
          <nav class="navbar navbar-expand-lg">
            <a class="navbar-brand" href="<?php if(isset($page) && $page != 1){ echo '../';} ?>">
              <img src="<?php if(isset($page) && $page != 1){ echo '../';} ?>assets/images/logo.png" alt="logo" />
            </a>
            <!-- logo -->

            <button
              class="navbar-toggler"
              type="button"
              data-toggle="collapse"
              data-target="#navbarSupportedContent"
              aria-controls="navbarSupportedContent"
              aria-expanded="false"
              aria-label="Toggle navigation"
            >
              <span class="toggler-icon"></span>
              <span class="toggler-icon"></span>
              <span class="toggler-icon"></span>
            </button>

            <div
              class="collapse navbar-collapse sub-menu-bar"
              id="navbarSupportedContent"
            >
              <ul class="navbar-nav m-auto">
                <li>
                  <a class="<?php if(isset($page) && $page == 1){ echo 'active';}else{ echo '';} ?>" href="<?php if(isset($page) && $page == 1){ echo '';}else{ echo '../';} ?>"
                    >Home <!--<i class="fa fa-angle-down"></i
                  >--></a>
                  <!--<ul class="sub-menu">
                    <li><a class="active" href="index.html">Home 01</a></li>
                    <li><a href="index-2.html">Home 02</a></li>
                    <li><a href="index-3.html">Home 03</a></li>
                    <li><a href="index-4.html">Home 04</a></li>
                    <li><a href="index-5.html">Home 05</a></li>
                    <li><a href="index-6.html">Home 06</a></li>
                  </ul>-->
                </li>
                <li>
                  <a class="<?php if(isset($page) && $page == 1){ echo '';}elseif(isset($page) && $page == 2 || $page == 3){ echo 'active';}else{ echo '';} ?>" href="<?php if(isset($page) && $page == 1){ echo 'about';}elseif(isset($page) && $page == 2){ echo '';}else{ echo '../about';} ?>">About <i class="fa fa-angle-down"></i></a>

                  <ul class="sub-menu">
                    <li><a href="<?php if(isset($page) && $page == 1){ echo 'about';}elseif(isset($page) && $page == 2){ echo '';}else{ echo '../about';} ?>">About</a></li>
                    <li><a href="<?php if(isset($page) && $page == 1){ echo 'volunteers';}elseif(isset($page) && $page == 3){ echo '';}else{ echo '../volunteers';} ?>">Volunteers</a></li>
                  </ul>
                </li>
                <li>
                  <a href="causes.html"
                    >Our Cuases <i class="fa fa-angle-down"></i
                  ></a>
                  <ul class="sub-menu">
                    <li><a href="causes.html">Cuases</a></li>
                    <li><a href="cause-details.html">Cuases Details</a></li>
                  </ul>
                </li>
                <li><a href="event.html">Events</a></li>
                <li>
                  <a href="blog.html">Blog <i class="fa fa-angle-down"></i></a>
                  <ul class="sub-menu">
                    <li><a href="blog.html">Blog</a></li>
                    <li><a href="blog-details.html">Blog Details</a></li>
                  </ul>
                </li>
                <li><a class="<?php if(isset($page) && $page == 1){ echo '';}elseif(isset($page) && $page == 7){ echo 'active';}else{ echo '';} ?>" href="<?php if(isset($page) && $page == 1){ echo 'contact';}elseif(isset($page) && $page == 7){ echo '';}else{ echo '../contact';} ?>">Contact</a></li>
              </ul>
            </div>
            <!-- navbar collapse -->

            <div class="navbar_btn d-none d-sm-block">
              <a class="main-btn" href="#"
                ><i class="fa fa-heart"></i> Donate Now</a
              >
            </div>
          </nav>
          <!-- navbar -->
        </div>
        <!-- container -->
      </div>
      <!-- header navbar -->
    </header>

    <!--====== HEADER PART ENDS ======-->
