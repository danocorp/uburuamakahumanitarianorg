<?php
    $page = 3; //initiate page variable
?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">

    <!--====== Title ======-->
    <title>Volunteers | Uburu Amaka Humanitarian Organization (UAHO)</title>
    <meta
      name="keywords"
      content="Uburu Amaka, Uburuamaka, Uburu Amaka Humanitarian, Humanitarian Organization, NGOs in Ebonyi State, Ohaozara LGA, Ebonyi Foundation"
    />
    <meta
      name="description"
      content="Uburu Amaka Humanitarian Organization is a platform that fosters community volunteer deployment and interaction based in Uburu Community, of Ohaozara Local government Area, Ebonyi State, Nigeria."
    />
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!--====== Favicon Icon ======-->
    <link rel="shortcut icon" href="../assets/images/favicon.png" type="image/png">

    <!--====== Magnific Popup CSS ======-->
    <link rel="stylesheet" href="../assets/css/magnific-popup.css">

    <!--====== Animate CSS ======-->
    <link rel="stylesheet" href="../assets/css/animate.css">

    <!--====== Slick CSS ======-->
    <link rel="stylesheet" href="../assets/css/slick.css">

    <!--====== Font Awesome CSS ======-->
    <link rel="stylesheet" href="../assets/css/font-awesome.min.css">

    <!--====== Bootstrap CSS ======-->
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">

    <!--====== Default CSS ======-->
    <link rel="stylesheet" href="../assets/css/default.css">

    <!--====== Style CSS ======-->
    <link rel="stylesheet" href="../assets/css/style.css">

</head>

<body>
    <!--[if IE]>
    <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
  <![endif]-->

    
    <!--====== PRELOADER PART START ======-->

     <div id="preloader">
        <div class="preloader">
            <span></span>
            <span></span>
        </div>
    </div>

    <!--====== PRELOADER PART ENDS ======-->


    <!--====== HEADER PART START ======-->

    <?php
        //include header file
        include("../includes/header.php");
    ?>
    <!--====== HEADER PART ENDS ======-->

    <!--====== PAGE BANNER PART START ======-->

    <section class="page_banner bg_cover" style="background-image: url(../assets/images/slider-1.jpg)">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="page_banner_content text-center">
                        <h3 class="page_title">Our Volunteers</h3>
                        <ul class="breadcrumb justify-content-center">
                            <li><a href="../">Home</a></li>
                            <li><a class="active" href="">Volunteers</a></li>
                        </ul>
                    </div> <!-- page banner content -->
                </div>
            </div> <!-- row -->
        </div> <!-- container -->
    </section>

    <!--====== PAGE BANNER PART ENDS ======-->
    
    <!--====== VOLUNTEER PART START ======-->

    <section class="volunteer_area pt-100 pb-130">
        <div class="services_shape_1" style="background-image: url(../assets/images/shape/shape-12.png)"></div>
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-sm-6">
                <div class="single_volunteer mt-30 volunteer_color_1">
                <div class="volunteer_image">
                    <img
                    src="../assets/images/ajah-thankgod-nwachinemere.jpg"
                    alt="Volunteer"
                    />
                    <div class="volunteer_social">
                    <ul class="social">
                        <li>
                        <a href="javascript:;"
                            ><i class="fa fa-facebook-square"></i
                        ></a>
                        </li>
                        <li>
                        <a href="javascript:;"
                            ><i class="fa fa-twitter-square"></i
                        ></a>
                        </li>
                        <li>
                        <a href="javascript:;"
                            ><i class="fa fa-linkedin-square"></i
                        ></a>
                        </li>
                        <li>
                        <a href="javascript:;"><i class="fa fa-instagram"></i></a>
                        </li>
                    </ul>
                    </div>
                    <!-- volunteer social -->
                </div>
                <div
                    class="volunteer_content d-flex align-items-center justify-content-center"
                >
                    <div class="content_wrapper">
                    <h5 class="volunteer_name"><a href="#">Ajah ThankGod</a></h5>
                    <p>Volunteer</p>
                    </div>
                </div>
                </div>
                <!-- single volunteer -->
            </div>
            <div class="col-lg-3 col-sm-6">
                <div class="single_volunteer mt-30 volunteer_color_2">
                <div class="volunteer_image">
                    <img src="../assets/images/gabriel-umahi.jpg" alt="Volunteer" />
                    <div class="volunteer_social">
                    <ul class="social">
                        <li>
                        <a href="javascript:;"
                            ><i class="fa fa-facebook-square"></i
                        ></a>
                        </li>
                        <li>
                        <a href="javascript:;"
                            ><i class="fa fa-twitter-square"></i
                        ></a>
                        </li>
                        <li>
                        <a href="javascript:;"
                            ><i class="fa fa-linkedin-square"></i
                        ></a>
                        </li>
                        <li>
                        <a href="javascript:;"><i class="fa fa-instagram"></i></a>
                        </li>
                    </ul>
                    </div>
                    <!-- volunteer social -->
                </div>
                <div
                    class="volunteer_content d-flex align-items-center justify-content-center"
                >
                    <div class="content_wrapper">
                    <h5 class="volunteer_name"><a href="#">Gabriel Umahi</a></h5>
                    <p>Volunteer</p>
                    </div>
                </div>
                </div>
                <!-- single volunteer -->
            </div>
            <div class="col-lg-3 col-sm-6">
                <div class="single_volunteer mt-30 volunteer_color_3">
                <div class="volunteer_image">
                    <img
                    src="../assets/images/jane-chinyere-oje.jpg"
                    alt="Volunteer"
                    />
                    <div class="volunteer_social">
                    <ul class="social">
                        <li>
                        <a href="javascript:;"
                            ><i class="fa fa-facebook-square"></i
                        ></a>
                        </li>
                        <li>
                        <a href="javascript:;"
                            ><i class="fa fa-twitter-square"></i
                        ></a>
                        </li>
                        <li>
                        <a href="javascript:;"
                            ><i class="fa fa-linkedin-square"></i
                        ></a>
                        </li>
                        <li>
                        <a href="javascript:;"><i class="fa fa-instagram"></i></a>
                        </li>
                    </ul>
                    </div>
                    <!-- volunteer social -->
                </div>
                <div
                    class="volunteer_content d-flex align-items-center justify-content-center"
                >
                    <div class="content_wrapper">
                    <h5 class="volunteer_name">
                        <a href="#">Jane Chinyere Oje</a>
                    </h5>
                    <p>Volunteer</p>
                    </div>
                </div>
                </div>
                <!-- single volunteer -->
            </div>
            <div class="col-lg-3 col-sm-6">
                <div class="single_volunteer mt-30 volunteer_color_4">
                <div class="volunteer_image">
                    <img
                    src="../assets/images/michael-chukwudi-odii.jpg"
                    alt="Volunteer"
                    />
                    <div class="volunteer_social">
                    <ul class="social">
                        <li>
                        <a href="javascript:;"
                            ><i class="fa fa-facebook-square"></i
                        ></a>
                        </li>
                        <li>
                        <a href="javascript:;"
                            ><i class="fa fa-twitter-square"></i
                        ></a>
                        </li>
                        <li>
                        <a href="javascript:;"
                            ><i class="fa fa-linkedin-square"></i
                        ></a>
                        </li>
                        <li>
                        <a href="javascript:;"><i class="fa fa-instagram"></i></a>
                        </li>
                    </ul>
                    </div>
                    <!-- volunteer social -->
                </div>
                <div
                    class="volunteer_content d-flex align-items-center justify-content-center"
                >
                    <div class="content_wrapper">
                    <h5 class="volunteer_name">
                        <a href="#">Michael Chukwudi Odii</a>
                    </h5>
                    <p>Volunteer</p>
                    </div>
                </div>
                </div>
                <!-- single volunteer -->
            </div>
            <div class="col-lg-3 col-sm-6">
                <div class="single_volunteer mt-30 volunteer_color_1">
                <div class="volunteer_image">
                    <img
                    src="../assets/images/sharon-ijuolachi-akpa.jpg"
                    alt="Volunteer"
                    />
                    <div class="volunteer_social">
                    <ul class="social">
                        <li>
                        <a href="javascript:;"
                            ><i class="fa fa-facebook-square"></i
                        ></a>
                        </li>
                        <li>
                        <a href="javascript:;"
                            ><i class="fa fa-twitter-square"></i
                        ></a>
                        </li>
                        <li>
                        <a href="javascript:;"
                            ><i class="fa fa-linkedin-square"></i
                        ></a>
                        </li>
                        <li>
                        <a href="javascript:;"><i class="fa fa-instagram"></i></a>
                        </li>
                    </ul>
                    </div>
                    <!-- volunteer social -->
                </div>
                <div
                    class="volunteer_content d-flex align-items-center justify-content-center"
                >
                    <div class="content_wrapper">
                    <h5 class="volunteer_name">
                        <a href="#">Sharon Ijuolachi Akpa</a>
                    </h5>
                    <p>Volunteer</p>
                    </div>
                </div>
                </div>
                <!-- single volunteer -->
            </div>
            <div class="col-lg-3 col-sm-6">
                <div class="single_volunteer mt-30 volunteer_color_2">
                <div class="volunteer_image">
                    <img
                    src="../assets/images/kingsley-abba-njoku-onu.jpg"
                    alt="Volunteer"
                    />
                    <div class="volunteer_social">
                    <ul class="social">
                        <li>
                        <a href="javascript:;"
                            ><i class="fa fa-facebook-square"></i
                        ></a>
                        </li>
                        <li>
                        <a href="javascript:;"
                            ><i class="fa fa-twitter-square"></i
                        ></a>
                        </li>
                        <li>
                        <a href="javascript:;"
                            ><i class="fa fa-linkedin-square"></i
                        ></a>
                        </li>
                        <li>
                        <a href="javascript:;"><i class="fa fa-instagram"></i></a>
                        </li>
                    </ul>
                    </div>
                    <!-- volunteer social -->
                </div>
                <div
                    class="volunteer_content d-flex align-items-center justify-content-center"
                >
                    <div class="content_wrapper">
                    <h5 class="volunteer_name">
                        <a href="#">Kingsley Abba Njoku</a>
                    </h5>
                    <p>Volunteer</p>
                    </div>
                </div>
                </div>
                <!-- single volunteer -->
            </div>
            <div class="col-lg-3 col-sm-6">
                <div class="single_volunteer mt-30 volunteer_color_3">
                <div class="volunteer_image">
                    <img
                    src="../assets/images/uzoigwe-doris.jpg"
                    alt="Volunteer"
                    />
                    <div class="volunteer_social">
                    <ul class="social">
                        <li>
                        <a href="javascript:;"
                            ><i class="fa fa-facebook-square"></i
                        ></a>
                        </li>
                        <li>
                        <a href="javascript:;"
                            ><i class="fa fa-twitter-square"></i
                        ></a>
                        </li>
                        <li>
                        <a href="javascript:;"
                            ><i class="fa fa-linkedin-square"></i
                        ></a>
                        </li>
                        <li>
                        <a href="javascript:;"><i class="fa fa-instagram"></i></a>
                        </li>
                    </ul>
                    </div>
                    <!-- volunteer social -->
                </div>
                <div
                    class="volunteer_content d-flex align-items-center justify-content-center"
                >
                    <div class="content_wrapper">
                    <h5 class="volunteer_name">
                        <a href="#">Uzoigwe Doris</a>
                    </h5>
                    <p>Volunteer</p>
                    </div>
                </div>
                </div>
                <!-- single volunteer -->
            </div>
            
            <div class="col-lg-3 col-sm-6">
                <div class="single_volunteer mt-30 volunteer_color_4">
                <div class="volunteer_image">
                    <img
                    src="../assets/images/david-ogbonnaya.jpg"
                    alt="Volunteer"
                    />
                    <div class="volunteer_social">
                    <ul class="social">
                        <li>
                        <a href="javascript:;"
                            ><i class="fa fa-facebook-square"></i
                        ></a>
                        </li>
                        <li>
                        <a href="javascript:;"
                            ><i class="fa fa-twitter-square"></i
                        ></a>
                        </li>
                        <li>
                        <a href="javascript:;"
                            ><i class="fa fa-linkedin-square"></i
                        ></a>
                        </li>
                        <li>
                        <a href="javascript:;"><i class="fa fa-instagram"></i></a>
                        </li>
                    </ul>
                    </div>
                    <!-- volunteer social -->
                </div>
                <div
                    class="volunteer_content d-flex align-items-center justify-content-center"
                >
                    <div class="content_wrapper">
                    <h5 class="volunteer_name">
                        <a href="#">David ogbonnaya</a>
                    </h5>
                    <p>Volunteer</p>
                    </div>
                </div>
                </div>
                <!-- single volunteer -->
            </div>

            </div> <!-- row -->
            <div class="row">
                <div class="col-lg-12">
                    <ul class="pagination justify-content-center mt-50">
                        <li class="page-item"><a href="#"><i class="fa fa-angle-left"></i></a></li>
                        <li class="page-item"><a class="active" href="#">1</a></li>
                        <li class="page-item"><a href="#">2</a></li>
                        <li class="page-item"><a href="#">3</a></li>
                        <li class="page-item"><a href="#"><i class="fa fa-angle-right"></i></a></li>
                    </ul> <!-- pagination -->
                </div>
            </div> <!-- row -->
        </div> <!-- container -->
    </section>

    <!--====== VOLUNTEER PART ENDS ======-->    

    <!--====== FOOTER PART START ======-->

    <?php
        //include footer
        include("../includes/footer.php");
    ?>
    <!--====== FOOTER PART ENDS ======-->

    <!--====== GO TO TOP PART START ======-->

    <div class="go-top-area">
        <div class="go-top-wrap">
            <div class="go-top-btn-wrap">
                <div class="go-top go-top-btn">
                    <i class="fa fa-angle-double-up"></i>
                    <i class="fa fa-angle-double-up"></i>
                </div>
            </div>
        </div>
    </div>

    <!--====== GO TO TOP PART ENDS ======-->




    <!--====== Jquery js ======-->
    <script src="../assets/js/vendor/jquery-1.12.4.min.js"></script>
    <script src="../assets/js/vendor/modernizr-3.7.1.min.js"></script>

    <!--====== Bootstrap js ======-->
    <script src="../assets/js/popper.min.js"></script>
    <script src="../assets/js/bootstrap.min.js"></script>

    <!--====== Slick js ======-->
    <script src="../assets/js/slick.min.js"></script>

    <!--====== Magnific Popup js ======-->
    <script src="../assets/js/jquery.magnific-popup.min.js"></script>

    <!--====== Appear js ======-->
    <script src="../assets/js/jquery.appear.min.js"></script>
    
    <!--====== Counter Up js ======-->
    <script src="../assets/js/waypoints.min.js"></script>
    <script src="../assets/js/jquery.counterup.js"></script>

    <!--====== wow js ======-->
    <script src="../assets/js/wow.min.js"></script>

    <!--====== Main js ======-->
    <script src="../assets/js/main.js"></script>

</body>

</html>
