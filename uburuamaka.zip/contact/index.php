<?php
    $page = 7; //initiate page variable
?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">

    <!--====== Title ======-->
    <title>Contact Us | Uburu Amaka Humanitarian Organization (UAHO)</title>
    <meta
      name="keywords"
      content="Uburu Amaka, Uburuamaka, Uburu Amaka Humanitarian, Humanitarian Organization, NGOs in Ebonyi State, Ohaozara LGA, Ebonyi Foundation"
    />
    <meta
      name="description"
      content="Uburu Amaka Humanitarian Organization is a platform that fosters community volunteer deployment and interaction based in Uburu Community, of Ohaozara Local government Area, Ebonyi State, Nigeria."
    />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <!--====== Favicon Icon ======-->
    <link
      rel="shortcut icon"
      href="../assets/images/favicon.png"
      type="image/png"
    />

    <!--====== Magnific Popup CSS ======-->
    <link rel="stylesheet" href="../assets/css/magnific-popup.css" />

    <!--====== Animate CSS ======-->
    <link rel="stylesheet" href="../assets/css/animate.css" />

    <!--====== Slick CSS ======-->
    <link rel="stylesheet" href="../assets/css/slick.css" />

    <!--====== Font Awesome CSS ======-->
    <link rel="stylesheet" href="../assets/css/font-awesome.min.css" />

    <!--====== Bootstrap CSS ======-->
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css" />

    <!--====== Default CSS ======-->
    <link rel="stylesheet" href="../assets/css/default.css" />

    <!--====== Style CSS ======-->
    <link rel="stylesheet" href="../assets/css/style.css" />
  </head>

  <body>
    <!--[if IE]>
      <p class="browserupgrade">
        You are using an <strong>outdated</strong> browser. Please
        <a href="https://browsehappy.com/">upgrade your browser</a> to improve
        your experience and security.
      </p>
    <![endif]-->

    <!--====== PRELOADER PART START ======-->

    <div id="preloader">
      <div class="preloader">
        <span></span>
        <span></span>
      </div>
    </div>

    <!--====== PRELOADER PART ENDS ======-->

    <!--====== HEADER PART START ======-->

    <?php
        //include header
        include("../includes/header.php");
    ?>

    <!--====== HEADER PART ENDS ======-->

    <!--====== PAGE BANNER PART START ======-->

    <section
      class="page_banner bg_cover"
      style="background-image: url(../assets/images/slider-1.jpg);"
    >
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="page_banner_content text-center">
              <h3 class="page_title">Contact</h3>
              <ul class="breadcrumb justify-content-center">
                <li><a href="#">Home</a></li>
                <li><a class="active" href="#">Event</a></li>
              </ul>
            </div>
            <!-- page banner content -->
          </div>
        </div>
        <!-- row -->
      </div>
      <!-- container -->
    </section>

    <!--====== PAGE BANNER PART ENDS ======-->

    <!--====== CONTACT PART START ======-->

    <section class="contact_area pt-100 pb-130">
      <div
        class="services_shape_1"
        style="background-image: url(../assets/images/shape/shape-12.png);"
      ></div>
      <div class="container">
        <div class="row">
          <div class="col-lg-8">
            <div class="contact_form mt-50">
              <div class="section_title pb-30">
                <img src="../assets/images/section_icon.png" alt="Icon" />
                <h3 class="title">Get in touch</h3>
              </div>
              <!-- section title -->
              <form action="#">
                <div class="row">
                  <div class="col-md-6">
                    <div class="single_form">
                      <input type="text" placeholder="Name" />
                    </div>
                    <!-- single form -->
                  </div>
                  <div class="col-md-6">
                    <div class="single_form">
                      <input type="email" placeholder="Email" />
                    </div>
                    <!-- single form -->
                  </div>
                  <div class="col-md-6">
                    <div class="single_form">
                      <input type="text" placeholder="Subject" />
                    </div>
                    <!-- single form -->
                  </div>
                  <div class="col-md-6">
                    <div class="single_form">
                      <input type="text" placeholder="Number" />
                    </div>
                    <!-- single form -->
                  </div>
                  <div class="col-md-12">
                    <div class="single_form">
                      <textarea placeholder="Massage"></textarea>
                    </div>
                    <!-- single form -->
                  </div>
                  <div class="col-md-12">
                    <div class="single_form">
                      <button class="main-btn">Send Message</button>
                    </div>
                    <!-- single form -->
                  </div>
                </div>
                <!-- row -->
              </form>
            </div>
            <!-- contact form -->
          </div>
          <div class="col-lg-4">
            <div class="contact_info pt-20">
              <ul>
                <li>
                  <div class="single_info d-flex align-items-center mt-30">
                    <div class="info_icon">
                      <i class="fa fa-home"></i>
                    </div>
                    <div class="info_content media-body">
                      <p>
                        Uburu Community Civic Centre, Eke-ajah, 
                        Uburu, Ohaozara L.G.A, Ebonyi State.
                      </p>
                    </div>
                  </div>
                  <!-- single info -->
                </li>
                <li>
                  <div class="single_info d-flex align-items-center mt-30">
                    <div class="info_icon">
                      <i class="fa fa-phone"></i>
                    </div>
                    <div class="info_content media-body">
                      <p>+2348032545494 </p>
                    </div>
                  </div>
                  <!-- single info -->
                </li>
                <li>
                  <div class="single_info d-flex align-items-center mt-30">
                    <div class="info_icon">
                      <i class="fa fa-envelope"></i>
                    </div>
                    <div class="info_content media-body">
                      <p>info@uburuamakahumanitarian.org</p>
                      <p>uburuamakanews@gmail.com</p>
                    </div>
                  </div>
                  <!-- single info -->
                </li>
              </ul>
            </div>
            <!-- contact info -->
            <div class="contact_map mt-50">
              <div class="gmap_canvas">
                <iframe
                  id="gmap_canvas"
                  src="https://maps.google.com/maps?q=Mission%20District%2C%20San%20Francisco%2C%20CA%2C%20USA&t=&z=13&ie=UTF8&iwloc=&output=embed"
                  frameborder="0"
                  scrolling="no"
                  marginheight="0"
                  marginwidth="0"
                ></iframe>
              </div>
            </div>
            <!-- contact map -->
          </div>
        </div>
        <!-- row -->
      </div>
      <!-- container -->
    </section>

    <!--====== CONTACT PART ENDS ======-->

    <!--====== FOOTER PART START ======-->

    <?php
        //include header
        include("../includes/footer.php");
    ?>
    <!--====== FOOTER PART ENDS ======-->

    <!--====== GO TO TOP PART START ======-->

    <div class="go-top-area">
      <div class="go-top-wrap">
        <div class="go-top-btn-wrap">
          <div class="go-top go-top-btn">
            <i class="fa fa-angle-double-up"></i>
            <i class="fa fa-angle-double-up"></i>
          </div>
        </div>
      </div>
    </div>

    <!--====== GO TO TOP PART ENDS ======-->

    <!--====== Jquery js ======-->
    <script src="../assets/js/vendor/jquery-1.12.4.min.js"></script>
    <script src="../assets/js/vendor/modernizr-3.7.1.min.js"></script>

    <!--====== Bootstrap js ======-->
    <script src="../assets/js/popper.min.js"></script>
    <script src="../assets/js/bootstrap.min.js"></script>

    <!--====== Slick js ======-->
    <script src="../assets/js/slick.min.js"></script>

    <!--====== Magnific Popup js ======-->
    <script src="../assets/js/jquery.magnific-popup.min.js"></script>

    <!--====== Appear js ======-->
    <script src="../assets/js/jquery.appear.min.js"></script>

    <!--====== Counter Up js ======-->
    <script src="../assets/js/waypoints.min.js"></script>
    <script src="../assets/js/jquery.counterup.js"></script>

    <!--====== wow js ======-->
    <script src="../assets/js/wow.min.js"></script>

    <!--====== Main js ======-->
    <script src="../assets/js/main.js"></script>
  </body>
</html>
