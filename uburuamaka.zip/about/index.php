<?php
    $page = 2; //initiate page variable
?>
<!DOCTYPE html>
<html class="no-js" lang="en">
  <head>
    <meta charset="utf-8" />

    <!--====== Title ======-->
    <title>About | Uburu Amaka Humanitarian Organization (UAHO)</title>
    <meta
      name="keywords"
      content="Uburu Amaka, Uburuamaka, Uburu Amaka Humanitarian, Humanitarian Organization, NGOs in Ebonyi State, Ohaozara LGA, Ebonyi Foundation"
    />
    <meta
      name="description"
      content="Uburu Amaka Humanitarian Organization is a platform that fosters community volunteer deployment and interaction based in Uburu Community, of Ohaozara Local government Area, Ebonyi State, Nigeria."
    />
    <meta name="viewport" content="width=device-width, initial-scale=1" />

    <!--====== Favicon Icon ======-->
    <link
      rel="shortcut icon"
      href="../assets/images/favicon.png"
      type="image/png"
    />

    <!--====== Magnific Popup CSS ======-->
    <link rel="stylesheet" href="../assets/css/magnific-popup.css" />

    <!--====== Animate CSS ======-->
    <link rel="stylesheet" href="../assets/css/animate.css" />

    <!--====== Slick CSS ======-->
    <link rel="stylesheet" href="../assets/css/slick.css" />

    <!--====== Font Awesome CSS ======-->
    <link rel="stylesheet" href="../assets/css/font-awesome.min.css" />

    <!--====== Bootstrap CSS ======-->
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css" />

    <!--====== Default CSS ======-->
    <link rel="stylesheet" href="../assets/css/default.css" />

    <!--====== Style CSS ======-->
    <link rel="stylesheet" href="../assets/css/style.css" />
  </head>

  <body>
    <!--[if IE]>
      <p class="browserupgrade">
        You are using an <strong>outdated</strong> browser. Please
        <a href="https://browsehappy.com/">upgrade your browser</a> to improve
        your experience and security.
      </p>
    <![endif]-->

    <!--====== PRELOADER PART START ======-->

    <div id="preloader">
      <div class="preloader">
        <span></span>
        <span></span>
      </div>
    </div>

    <!--====== PRELOADER PART ENDS ======-->
    <?php
        //include header
        include("../includes/header.php");
    ?>

    <!--====== PAGE BANNER PART START ======-->

    <section
      class="page_banner bg_cover"
      style="background-image: url(../assets/images/slider-1.jpg);"
    >
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="page_banner_content text-center">
              <h3 class="page_title">About us</h3>
              <ul class="breadcrumb justify-content-center">
                <li><a href="../">Home</a></li>
                <li><a class="active" href="">About</a></li>
              </ul>
            </div>
            <!-- page banner content -->
          </div>
        </div>
        <!-- row -->
      </div>
      <!-- container -->
    </section>

    <!--====== PAGE BANNER PART ENDS ======-->

    <!--====== ABOUT PART START ======-->

    <section class="about_area pt-80 pb-130">
      <div
        class="services_shape_1"
        style="background-image: url(../assets/images/shape/shape-12.png);"
      ></div>
      <div class="container">
        <div class="row align-items-center">
          <div class="col-lg-6">
            <div class="about_image mt-50">
              <div class="image_1">
                <img src="../assets/images/about-0-1.jpg" alt="about" />
              </div>
              <div class="image_2">
                <img src="../assets/images/about-1-2.jpg" alt="about" />
              </div>
            </div>
            <!-- about image -->
          </div>
          <div class="col-lg-6">
            <div class="about_content_3 mt-45">
              <h3 class="about_title">
                We are a Humanitarian Organization.
              </h3>
              <p>
                Uburu Amaka Humanitarian Organization is a platform for
                community volunteer deployment and interaction, offering
                humanitarian support to those in need of assistance for care
                given among elderly, education and skill development among
                young people, health care for all, housing and pursuit of
                social justice and eradication of all barriers that fosters
                segregation and discrimination in Uburu Community, of Ohaozara
                Local Government Area, Ebonyi State, Nigeria.
              </p>
            </div>
            <!-- about image -->
          </div>
        </div>
        <!-- row -->
      </div>
      <!-- container -->
    </section>

    <!--====== ABOUT PART ENDS ======-->

    <!--====== SERVICES PART START ======-->

    <section
      class="services_area_2 pt-130 pb-130 bg_cover"
      style="background-image: url(../assets/images/gray-bg.jpg);"
    >
      <div
        class="services_shape_1"
        style="background-image: url(../assets/images/shape/shape-1.png);"
      ></div>
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="section_title text-center pb-30">
              <img src="../assets/images/section_icon.png" alt="Icon" />
              <h3 class="title">What we do</h3>
            </div>
            <!-- section title -->
          </div>
        </div>
        <!-- row -->
        <div class="row justify-content-center">
          <div class="col-lg-4 col-md-7">
            <div class="single_services_2 text-center mt-30 services_2_color_1">
              <div class="services_image">
                <a href="#"
                  ><img src="../assets/images/services-3.jpg" alt="help"
                /></a>
              </div>
              <div class="services_content">
                <h4 class="services_title"><a href="#">Be a Volunteer</a></h4>
                <p>
                  UAHO is a nonproﬁt organization open to great minds, join our
                  volunteer group on facebook to get updates.
                </p>
              </div>
            </div>
            <!-- single help -->
          </div>
          <div class="col-lg-4 col-md-7">
            <div class="single_services_2 text-center mt-30 services_2_color_2">
              <div class="services_image">
                <a href="#"
                  ><img src="../assets/images/services-2.jpg" alt="help"
                /></a>
              </div>
              <div class="services_content">
                <h4 class="services_title"><a href="#">Donate Now</a></h4>
                <p>
                  UAHO is a nonproﬁt organization supported by community
                  leaders, corporate sponsors, and churches.
                </p>
              </div>
            </div>
            <!-- single help -->
          </div>
          <div class="col-lg-4 col-md-7">
            <div class="single_services_2 text-center mt-30 services_2_color_3">
              <div class="services_image">
                <a href="#"
                  ><img src="../assets/images/services-1.jpg" alt="help"
                /></a>
              </div>
              <div class="services_content">
                <h4 class="services_title"><a href="#">Send Gift</a></h4>
                <p>
                  UAHO is out to revive lost hope and provide care to the less
                  priviledged, you can join our campaign.
                </p>
              </div>
            </div>
            <!-- single help -->
          </div>
        </div>
        <!-- row -->
      </div>
      <!-- container -->
      <div
        class="services_shape_2"
        style="background-image: url(../assets/images/shape/shape-2.png);"
      ></div>
    </section>

    <!--====== SERVICES PART ENDS ======-->

    <!--====== VIDEO PART START ======-->

    <section
      class="video_area_3 pt-80 pb-130 bg_cover"
      style="background-image: url(../assets/images/food-response.jpg);"
    >
      <div class="container">
        <div class="row align-items-center">
          <div class="col-lg-6">
            <div class="video_image mt-50">
              <img src="../assets/images/video-image.jpg" alt="video" />
              <a
                href="https://www.youtube.com/watch?v=WKUjCCOcLFY"
                class="video-popup"
              >
                <i class="fa fa-play"></i>
                <img src="../assets/images/shape/shape-3.png" alt="shape" />
              </a>
            </div>
            <!-- about video -->
          </div>
          <div class="col-lg-6">
            <div class="video_content_3 mt-45">
              <h4 class="video_title">We served more than 1,300 poor people</h4>
              <p>
                Uburu Amaka Humanitarian organization is a nonproﬁt organization supported by community
                leaders, corporate sponsors, churches and concerned citizens. 
                There will be a day–in our lifetime–when we get to celebrate our contribution to the less-priviledged in our society.
              </p>
              <a href="#" class="main-btn"
                ><i class="fa fa-heart"></i> Donate Now</a
              >
            </div>
            <!-- about content -->
          </div>
        </div>
        <!-- row -->
      </div>
      <!-- container -->
    </section>

    <!--====== VIDEO PART ENDS ======-->

    <!--====== VOLUNTEER PART START ======-->

    <section class="volunteer_area pt-130 pb-130">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="section_title text-center pb-30">
              <img src="../assets/images/section_icon.png" alt="Icon" />
              <h3 class="title">Our Directors</h3>
            </div>
            <!-- section title -->
          </div>
        </div>
        <!-- row -->
        <div class="row">
            <div class="col-lg-4 col-md-3 col-6">
              <div class="single_doner mt-30 text-center doner_color-1">
                <div class="doner_image">
                  <img
                    src="../assets/images/dr-oje-ogbonnaya-einstein.jpg"
                    alt="doner"
                  />
                </div>
                <div class="doner_content">
                  <h5 class="doner_name">Dr. Oje Ogbonnaya Einstein</h5>
                  <p>Director- Health Services</p>
                </div>
              </div>
              <!-- single doner -->
            </div>
            <div class="col-lg-4 col-md-3 col-6">
              <div class="single_doner mt-30 text-center doner_color-2">
                <div class="doner_image">
                  <img
                    src="../assets/images/paul-ogbonnaya-junior.jpg"
                    alt="doner"
                  />
                </div>
                <div class="doner_content">
                  <h5 class="doner_name">Paul Ogbonnaya Junior</h5>
                  <p>Director - Media, Planning & Strategy</p>
                </div>
              </div>
              <!-- single doner -->
            </div>
            <div class="col-lg-4 col-md-3 col-6">
              <div class="single_doner mt-30 text-center doner_color-3">
                <div class="doner_image">
                  <img src="../assets/images/onu-nicholas-odi.jpg" alt="doner" />
                </div>
                <div class="doner_content">
                  <h5 class="doner_name">Onu Nicholas Odi</h5>
                  <p>Executive Administrator/Chief Executive</p>
                </div>
              </div>
              <!-- single doner -->
            </div>
            <div class="col-lg-4 col-md-3 col-6">
              <div class="single_doner mt-30 text-center doner_color-4">
                <div class="doner_image">
                  <img src="../assets/images/santos-felix-okike.jpg" alt="doner" />
                </div>
                <div class="doner_content">
                  <h5 class="doner_name">Santos Felix Okike</h5>
                  <p>Director Global Outreach & fundraising</p>
                </div>
              </div>
              <!-- single doner -->
            </div>
            <div class="col-lg-4 col-md-3 col-6">
              <div class="single_doner mt-30 text-center doner_color-4">
                <div class="doner_image">
                  <img src="../assets/images/akpa-igwe.jpg" alt="doner" />
                </div>
                <div class="doner_content">
                  <h5 class="doner_name">Akpa Igwe</h5>
                  <p>Moderator - Community Development Consultant</p>
                </div>
              </div>
              <!-- single doner -->
            </div>
          </div>
          <!-- row -->
      </div>
      <!-- container -->
    </section>

    <!--====== VOLUNTEER PART ENDS ======-->

    <!--====== TESTIMONIAL PART START ======-->

    <section class="testimonial_area">
      <div class="testimonial_image_wrapper">
        <div class="single_testimonial_image">
          <img src="../assets/images/testimonial-1.jpg" alt="testimonial" />
        </div>
        <!-- single testimonial image -->

        <div class="single_testimonial_image">
          <img src="../assets/images/testimonial-2.jpg" alt="testimonial" />
        </div>
        <!-- single testimonial image -->

        <div class="single_testimonial_image">
          <img src="../assets/images/testimonial-3.jpg" alt="testimonial" />
        </div>
        <!-- single testimonial image -->

        <div class="single_testimonial_image">
          <img src="../assets/images/testimonial-2.jpg" alt="testimonial" />
        </div>
        <!-- single testimonial image -->
      </div>
      <!-- testimonial image wrapper -->

      <div class="testimonial_content_area">
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-lg-6">
              <div class="testimonial_content_wrapper">
                <div class="single_testimonial_content text-center">
                  <i class="fa fa-quote-right"></i>
                  <h4 class="testimonial_title">Testimonial</h4>
                  <p>
                    Helpgrove is a nonproﬁt organization supported by community
                    leaders, corporate sponsors, churches, helpless etc. and
                    concerned citizens
                  </p>
                  <h6 class="author_name">Alex Heyden</h6>
                </div>
                <!-- single testimonial content -->

                <div class="single_testimonial_content text-center">
                  <i class="fa fa-quote-right"></i>
                  <h4 class="testimonial_title">Testimonial</h4>
                  <p>
                    Helpgrove is a nonproﬁt organization supported by community
                    leaders, corporate sponsors, churches, helpless etc. and
                    concerned citizens
                  </p>
                  <h6 class="author_name">Alex Heyden</h6>
                </div>
                <!-- single testimonial content -->

                <div class="single_testimonial_content text-center">
                  <i class="fa fa-quote-right"></i>
                  <h4 class="testimonial_title">Testimonial</h4>
                  <p>
                    Helpgrove is a nonproﬁt organization supported by community
                    leaders, corporate sponsors, churches, helpless etc. and
                    concerned citizens
                  </p>
                  <h6 class="author_name">Alex Heyden</h6>
                </div>
                <!-- single testimonial content -->

                <div class="single_testimonial_content text-center">
                  <i class="fa fa-quote-right"></i>
                  <h4 class="testimonial_title">Testimonial</h4>
                  <p>
                    Helpgrove is a nonproﬁt organization supported by community
                    leaders, corporate sponsors, churches, helpless etc. and
                    concerned citizens
                  </p>
                  <h6 class="author_name">Alex Heyden</h6>
                </div>
                <!-- single testimonial content -->
              </div>
              <!-- row -->
            </div>
          </div>
          <!-- row -->
        </div>
        <!-- container -->
      </div>
      <!-- testimonial content area -->
    </section>

    <!--====== TESTIMONIAL PART ENDS ======-->

    <!--====== BRAND PART START ======-->

    <section class="volunteer_support pt-125 pb-130">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="support_title text-center">
              <h4 class="title">
                <i>Our trusted donors & organizations who support us</i>
              </h4>
            </div>
            <!-- support title -->
          </div>
        </div>
        <!-- row -->
        <div class="row">
          <div class="col-lg-3 col-sm-6">
            <div class="single_support d-flex align-items-center mt-30">
              <div class="support_logo">
                <img src="../assets/images/logo-2.png" alt="Logo" />
              </div>
              <div class="support_content media-body">
                <h5 class="title">Ego Bekee Foundation</h5>
              </div>
            </div>
            <!-- support title -->
          </div>
          <div class="col-lg-3 col-sm-6">
            <div
              class="single_support d-flex align-items-center justify-content-center mt-30"
            >
              <div class="support_logo">
                <img src="../assets/images/logo-2.png" alt="Logo" />
              </div>
              <div class="support_content media-body">
                <h5 class="title">CUTEC Aluminum</h5>
                <!--<p>for your logo here</p>-->
              </div>
            </div>
            <!-- support title -->
          </div>
          <div class="col-lg-3 col-sm-6">
            <div
              class="single_support d-flex align-items-center justify-content-center mt-30"
            >
              <div class="support_logo">
                <img src="../assets/images/logo-2.png" alt="Logo" />
              </div>
              <div class="support_content media-body">
                <h5 class="title">Ebere Anyichuks Foundation</h5>
              </div>
            </div>
            <!-- support title -->
          </div>
          <div class="col-lg-3 col-sm-6">
            <div
              class="single_support d-flex align-items-center justify-content-center mt-30"
            >
              <div class="support_logo">
                <img src="../assets/images/logo-2.png" alt="Logo" />
              </div>
              <div class="support_content media-body">
                <h5 class="title">Comrade Christian Chukwu</h5>
              </div>
            </div>
            <!-- support title -->
          </div>
        </div>
        <!-- row -->
      </div>
      <!-- container -->
    </section>

    <!--====== BRAND PART ENDS ======-->

   
    <?php
        //include header
        include("../includes/footer.php");
    ?>


    <!--====== GO TO TOP PART START ======-->

    <div class="go-top-area">
      <div class="go-top-wrap">
        <div class="go-top-btn-wrap">
          <div class="go-top go-top-btn">
            <i class="fa fa-angle-double-up"></i>
            <i class="fa fa-angle-double-up"></i>
          </div>
        </div>
      </div>
    </div>

    <!--====== GO TO TOP PART ENDS ======-->

    <!--====== Jquery js ======-->
    <script src="../assets/js/vendor/jquery-1.12.4.min.js"></script>
    <script src="../assets/js/vendor/modernizr-3.7.1.min.js"></script>

    <!--====== Bootstrap js ======-->
    <script src="../assets/js/popper.min.js"></script>
    <script src="../assets/js/bootstrap.min.js"></script>

    <!--====== Slick js ======-->
    <script src="../assets/js/slick.min.js"></script>

    <!--====== Magnific Popup js ======-->
    <script src="../assets/js/jquery.magnific-popup.min.js"></script>

    <!--====== Appear js ======-->
    <script src="../assets/js/jquery.appear.min.js"></script>

    <!--====== Counter Up js ======-->
    <script src="../assets/js/waypoints.min.js"></script>
    <script src="../assets/js/jquery.counterup.js"></script>

    <!--====== wow js ======-->
    <script src="../assets/js/wow.min.js"></script>

    <!--====== Main js ======-->
    <script src="../assets/js/main.js"></script>
  </body>
</html>
